import{n as t,Y as e,t as r,p as l,O as a,s as o}from"./5d0d5f73-ae5c-424f-a591-eb75345795bb.js";var i=Object.defineProperty,s=Object.getOwnPropertyDescriptor,h=(t,e,r,l)=>{for(var a,o=l>1?void 0:l?s(e,r):e,h=t.length-1;h>=0;h--)(a=t[h])&&(o=(l?a(e,r,o):a(o))||o);return l&&o&&i(e,r,o),o};let p=class extends t{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return e`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${p.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};p.weightsMap=new Map([["thin",r`<path d="M178.83,130.83l-80,80a4,4,0,0,1-5.66-5.66L170.34,128,93.17,50.83a4,4,0,0,1,5.66-5.66l80,80A4,4,0,0,1,178.83,130.83Z"/>`],["light",r`<path d="M180.24,132.24l-80,80a6,6,0,0,1-8.48-8.48L167.51,128,91.76,52.24a6,6,0,0,1,8.48-8.48l80,80A6,6,0,0,1,180.24,132.24Z"/>`],["regular",r`<path d="M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z"/>`],["bold",r`<path d="M184.49,136.49l-80,80a12,12,0,0,1-17-17L159,128,87.51,56.49a12,12,0,1,1,17-17l80,80A12,12,0,0,1,184.49,136.49Z"/>`],["fill",r`<path d="M181.66,133.66l-80,80A8,8,0,0,1,88,208V48a8,8,0,0,1,13.66-5.66l80,80A8,8,0,0,1,181.66,133.66Z"/>`],["duotone",r`<path d="M176,128,96,208V48Z" opacity="0.2"/><path d="M181.66,122.34l-80-80A8,8,0,0,0,88,48V208a8,8,0,0,0,13.66,5.66l80-80A8,8,0,0,0,181.66,122.34ZM104,188.69V67.31L164.69,128Z"/>`]]),p.styles=l`
    :host {
      display: contents;
    }
  `,h([a({type:String,reflect:!0})],p.prototype,"size",2),h([a({type:String,reflect:!0})],p.prototype,"weight",2),h([a({type:String,reflect:!0})],p.prototype,"color",2),h([a({type:Boolean,reflect:!0})],p.prototype,"mirrored",2),p=h([o("ph-caret-right")],p);export{p as PhCaretRight};
