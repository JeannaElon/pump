import{n as t,Y as e,t as r,p as a,O as l,s as o}from"./5d0d5f73-ae5c-424f-a591-eb75345795bb.js";var i=Object.defineProperty,s=Object.getOwnPropertyDescriptor,h=(t,e,r,a)=>{for(var l,o=a>1?void 0:a?s(e,r):e,h=t.length-1;h>=0;h--)(l=t[h])&&(o=(a?l(e,r,o):l(o))||o);return a&&o&&i(e,r,o),o};let p=class extends t{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return e`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${p.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};p.weightsMap=new Map([["thin",r`<path d="M218.83,130.83l-72,72a4,4,0,0,1-5.66-5.66L206.34,132H40a4,4,0,0,1,0-8H206.34L141.17,58.83a4,4,0,0,1,5.66-5.66l72,72A4,4,0,0,1,218.83,130.83Z"/>`],["light",r`<path d="M220.24,132.24l-72,72a6,6,0,0,1-8.48-8.48L201.51,134H40a6,6,0,0,1,0-12H201.51L139.76,60.24a6,6,0,0,1,8.48-8.48l72,72A6,6,0,0,1,220.24,132.24Z"/>`],["regular",r`<path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"/>`],["bold",r`<path d="M224.49,136.49l-72,72a12,12,0,0,1-17-17L187,140H40a12,12,0,0,1,0-24H187L135.51,64.48a12,12,0,0,1,17-17l72,72A12,12,0,0,1,224.49,136.49Z"/>`],["fill",r`<path d="M221.66,133.66l-72,72A8,8,0,0,1,136,200V136H40a8,8,0,0,1,0-16h96V56a8,8,0,0,1,13.66-5.66l72,72A8,8,0,0,1,221.66,133.66Z"/>`],["duotone",r`<path d="M216,128l-72,72V56Z" opacity="0.2"/><path d="M221.66,122.34l-72-72A8,8,0,0,0,136,56v64H40a8,8,0,0,0,0,16h96v64a8,8,0,0,0,13.66,5.66l72-72A8,8,0,0,0,221.66,122.34ZM152,180.69V75.31L204.69,128Z"/>`]]),p.styles=a`
    :host {
      display: contents;
    }
  `,h([l({type:String,reflect:!0})],p.prototype,"size",2),h([l({type:String,reflect:!0})],p.prototype,"weight",2),h([l({type:String,reflect:!0})],p.prototype,"color",2),h([l({type:Boolean,reflect:!0})],p.prototype,"mirrored",2),p=h([o("ph-arrow-right")],p);export{p as PhArrowRight};
